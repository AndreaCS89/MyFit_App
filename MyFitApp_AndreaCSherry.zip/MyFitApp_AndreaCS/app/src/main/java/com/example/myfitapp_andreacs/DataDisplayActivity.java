package com.example.myfitapp_andreacs;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class DataDisplayActivity extends AppCompatActivity {

    private DataAdapter dataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);  // Converted to local variable
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dataAdapter = new DataAdapter();  // Kept as an instance variable for use in addData
        recyclerView.setAdapter(dataAdapter);
    }

    public void addData(View view) {
        // Logic to add data to the RecyclerView
        dataAdapter.addData(new DataItem("New Data"));
    }
}

