package com.example.myfitapp_andreacs;

public class DataItem {
    private final String data;

    public DataItem(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }
}

