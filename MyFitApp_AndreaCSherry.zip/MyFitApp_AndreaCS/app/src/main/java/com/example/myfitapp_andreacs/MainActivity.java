package com.example.myfitapp_andreacs;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;

    // Declare an instance of DatabaseHelper
    private DatabaseHelper db;

    private boolean isSmsPermissionGranted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the DatabaseHelper
        db = new DatabaseHelper(this);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setEnabled(false);
        buttonCreateAccount.setEnabled(false);

        // SMS Permission Check
        checkSmsPermission();

        // TextWatcher to enable/disable buttons based on input
        TextWatcher loginTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not used
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                boolean isUsernameFilled = editTextUsername.getText().length() > 0;
                boolean isPasswordFilled = editTextPassword.getText().length() > 0;
                buttonLogin.setEnabled(isUsernameFilled && isPasswordFilled);
                buttonCreateAccount.setEnabled(isUsernameFilled && isPasswordFilled);
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Not used
            }
        };

        editTextUsername.addTextChangedListener(loginTextWatcher);
        editTextPassword.addTextChangedListener(loginTextWatcher);
    }

    // Check if the SMS permission is granted, if not, request it
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Request permission
            requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        } else {
            // Permission already granted
            isSmsPermissionGranted = true;
            Toast.makeText(this, "SMS Permission is granted", Toast.LENGTH_SHORT).show();
        }
    }

    // ActivityResultLauncher to request SMS permission
    private final ActivityResultLauncher<String> requestSmsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    isSmsPermissionGranted = true;
                    Toast.makeText(this, "SMS Permission granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "SMS Permission denied", Toast.LENGTH_SHORT).show();
                }
            });

    // Method for the Login button
    public void login(View view) {
        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();

        // Check if the user exists in the database
        if (db.checkUser(username, password)) {
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();

            // Redirect to UserDashboardActivity after successful login
            Intent intent = new Intent(MainActivity.this, UserDashboardActivity.class);
            intent.putExtra("USERNAME", username);
            intent.putExtra("SMS_PERMISSION_GRANTED", isSmsPermissionGranted);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    // Method for the Create Account button
    public void createAccount(View view) {
        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();
        boolean isInserted = db.insertUser(username, password);

        if (isInserted) {
            Toast.makeText(this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Account Creation Failed", Toast.LENGTH_SHORT).show();
        }
    }
}


