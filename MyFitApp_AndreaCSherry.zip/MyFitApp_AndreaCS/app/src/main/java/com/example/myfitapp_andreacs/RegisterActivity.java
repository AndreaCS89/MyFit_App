package com.example.myfitapp_andreacs;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    // Declare DatabaseHelper
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize DatabaseHelper
        db = new DatabaseHelper(this);

        // Convert these fields to local variables because they are only used in this method
        EditText editTextNewUsername = findViewById(R.id.editTextNewUsername);
        EditText editTextNewPassword = findViewById(R.id.editTextNewPassword);
        Button buttonRegister = findViewById(R.id.buttonRegister);

        // Use lambda expression instead of an anonymous class for the OnClickListener
        buttonRegister.setOnClickListener(view -> {
            String newUsername = editTextNewUsername.getText().toString();
            String newPassword = editTextNewPassword.getText().toString();

            // Save the new user to the database
            boolean isInserted = db.insertUser(newUsername, newPassword);
            if (isInserted) {
                Toast.makeText(RegisterActivity.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                finish(); // Close the activity and return to login screen
            } else {
                Toast.makeText(RegisterActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
