package com.example.myfitapp_andreacs;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);
    }

    // Method to request SMS permission
    public void requestSmsPermission(View view) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted, so request it
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            // Permission already granted
            Toast.makeText(this, "SMS Permission is already granted", Toast.LENGTH_SHORT).show();
            proceedToMainFunctionality(true); // Proceed with SMS permission granted
        }
    }

    // Handle the user's response to the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Toast.makeText(this, "SMS Permission granted", Toast.LENGTH_SHORT).show();
                proceedToMainFunctionality(true); // Proceed with SMS functionality
            } else {
                // Permission denied
                Toast.makeText(this, "SMS Permission denied", Toast.LENGTH_SHORT).show();
                proceedToMainFunctionality(false); // Proceed without SMS functionality
            }
        }
    }

    // Method to proceed to main functionality of the app based on SMS permission status
    private void proceedToMainFunctionality(boolean smsGranted) {
        Intent intent = new Intent(SmsPermissionActivity.this, MainActivity.class);
        intent.putExtra("SMS_PERMISSION_GRANTED", smsGranted);
        startActivity(intent);
        finish(); // Close the current activity
    }
}
