package com.example.myfitapp_andreacs;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UserDashboardActivity extends AppCompatActivity {

    private Button buttonDeleteAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);

        // Initialize Delete Account button
        buttonDeleteAccount = findViewById(R.id.buttonDeleteAccount);

        // Get the username from the intent
        Intent intent = getIntent();
        String username = intent.getStringExtra("USERNAME");

        // Handle Delete Account button click
        buttonDeleteAccount.setOnClickListener(v -> deleteAccount(username));
    }

    // Method for deleting account
    private void deleteAccount(String username) {
        // Simulate account deletion logic
        Toast.makeText(this, "Account Deleted Successfully for " + username, Toast.LENGTH_SHORT).show();
    }
}





